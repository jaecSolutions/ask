from aws_lambda_powertools import Tracer, Logger

LOGGER = Logger()
TRACER = Tracer()

@TRACER.capture_lambda_handler
@LOGGER.inject_lambda_context(log_event=True)
def handler(event, context):
    return {    
        "statusCode": 200,
        "body": "Hello, World!"
    }
